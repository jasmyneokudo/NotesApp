package com.example.notesapp;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class EditNoteActivity extends AppCompatActivity {

    EditText titleEditText;
    EditText noteEditText;
    NotesDatabase notesDatabase;
    String formattedDate;
    String action;
    MenuItem saveMenu;
    String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_note);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        titleEditText = findViewById(R.id.note_title_et);
        noteEditText = findViewById(R.id.note_et);

        id = getIntent().getStringExtra("id");
        action = getIntent().getStringExtra("action");

        if (action.equals("view")){

            String title = getIntent().getStringExtra("title");
            String note = getIntent().getStringExtra("desc");

            setTitle(title);
            titleEditText.setText(title);
            noteEditText.setText(note);


            titleEditText.setEnabled(false);
            noteEditText.setEnabled(false);

        }

        // notes database object instantiation
        notesDatabase = new NotesDatabase(this);

        // get current date of device
        Date currentDate = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
        formattedDate = df.format(currentDate);



        final FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                titleEditText.setEnabled(true);
                noteEditText.setEnabled(true);

                action = "edit";
                saveMenu.setEnabled(true);
                fab.setVisibility(View.GONE);

            }
        });
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.notes_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {

        saveMenu = menu.findItem(R.id.save_menu);

        if (action.equals("view")) {
            saveMenu.setEnabled(false);
        }

        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();
        if (id == R.id.save_menu) {

            String title = titleEditText.getText().toString();
            String note = noteEditText.getText().toString();

            if (title.isEmpty())
                Snackbar.make(noteEditText, "Enter a note title firat", Snackbar.LENGTH_LONG).show();
            else {

                if (action.equals("edit")) {

                    notesDatabase.updateData(Integer.parseInt(this.id), title, note);

                    Intent intent  = new Intent(EditNoteActivity.this, NotesActivity.class);
                    startActivity(intent);

                    Toast.makeText(this, "Succrssful!", Toast.LENGTH_SHORT).show();

                }else {
                    boolean isSuccessful = notesDatabase.insertData(title, note, formattedDate);
                    if (isSuccessful) {

                        Intent intent  = new Intent(EditNoteActivity.this, NotesActivity.class);
                        startActivity(intent);
                        Toast.makeText(this, "Succrssful!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Note was not saved!", Toast.LENGTH_SHORT).show();
                    }
                }
            }

        }
        return super.onOptionsItemSelected(item);
    }
}
