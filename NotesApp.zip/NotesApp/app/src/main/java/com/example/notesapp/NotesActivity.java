package com.example.notesapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;

public class NotesActivity extends AppCompatActivity {


    public static NotesDatabase notesDatabase;
    RecyclerView recyclerView;
    TextView notifTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notes);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        recyclerView = findViewById(R.id.notes_rv);
        notifTextView = findViewById(R.id.notification_tv);

        // notes database object instatiation
        notesDatabase = new NotesDatabase(this);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(NotesActivity.this, EditNoteActivity.class);
                intent.putExtra("action", "add");
                startActivity(intent);
            }
        });

        getNotes();
    }

    public void getNotes(){

        ArrayList<Note> notes = new ArrayList<>();
        Cursor cursor = notesDatabase.readData();


        // get column indexex
        int idIndex = cursor.getColumnIndex("ID");
        int noteTitleIndex = cursor.getColumnIndex("NOTE_TITLE");
        int noteIndex = cursor.getColumnIndex("NOTE");
        int dateIndex = cursor.getColumnIndex("DATE");

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {

            String id = String.valueOf(cursor.getInt(idIndex));
            String noteTitle = cursor.getString(noteTitleIndex);
            String note = cursor.getString(noteIndex);
            String date = cursor.getString(dateIndex);

            Note newNote = new Note(id, noteTitle, note, date);
            notes.add(newNote);

            cursor.moveToNext();
        }

        if (!notes.isEmpty()) {
            notifTextView.setVisibility(View.GONE);

            NotesAdapter notesAdapter = new NotesAdapter(notes, NotesActivity.this);
            LinearLayoutManager layoutManager = new LinearLayoutManager(NotesActivity.this);

            // ataching adaptet and layoutmanager to our recycler view
            recyclerView.setAdapter(notesAdapter);
            recyclerView.setLayoutManager(layoutManager);
        }



    }

}
