package com.example.notesapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class NotesAdapter extends RecyclerView.Adapter<NotesAdapter.ViewHolder> {


    ArrayList<Note> notes = new ArrayList<>();
    Context context;

    // cOnstructor
    public NotesAdapter(ArrayList<Note> notes, Context context) {

        this.context = context;
        this.notes = notes;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.list_item, parent, false);

        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Note note = notes.get(position);
        final String id = note.getId();
        final String title = note.getNoteTitle();
        final String desc = note.getNoteDesc();
        String date = note.getDate();

        holder.titleTextView.setText(title);
        holder.descTextView.setText(desc);
        holder.dateTextView.setText(date);

        holder.relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(context, EditNoteActivity.class);
                intent.putExtra("action", "view");
                intent.putExtra("id", id);
                intent.putExtra("title", title);
                intent.putExtra("desc", desc);
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return notes.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        RelativeLayout relativeLayout;
        TextView titleTextView;
        TextView descTextView;
        TextView dateTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            relativeLayout = itemView.findViewById(R.id.container);
            titleTextView = itemView.findViewById(R.id.note_title_tv);
            descTextView = itemView.findViewById(R.id.note_desc_tv);
            dateTextView = itemView.findViewById(R.id.date_tv);

        }
    }
}
