package com.example.notesapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class NotesDatabase extends SQLiteOpenHelper {

    public static final String DB_NAME = "NotesApp.db"; // database name
    public static final String TABLE_NAME = "ALL_NOTES"; // table name

    // column namees
    private static final String COL_1 = "ID";
    private static final String COL_2 = "NOTE_TITLE";
    private static final String COL_3 = "NOTE";
    private static final String COL_4 = "DATE";


    public NotesDatabase(@Nullable Context context) {
        super(context, DB_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String sql = "CREATE TABLE "+TABLE_NAME +"" +
                " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "NOTE_TITLE TEXT NOT NULL, " +
                " NOTE TEXT," +
                " DATE TEXT NOT NULL) ";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(db);

    }

    // insert data into table
    public boolean insertData(String noteTitle, String note, String date){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(COL_2, noteTitle);
        contentValues.put(COL_3, note);
        contentValues.put(COL_4, date);

        long value = db.insert(TABLE_NAME, null, contentValues);
        if (value == -1)
            return false;
        else
            return true;

    }

    // read data
    public Cursor readData(){

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM "+TABLE_NAME, null);
        return cursor;
    }

    // select data
    public Cursor readSingleData(int id) {

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM "+TABLE_NAME+" where id = "+id, null);
        return cursor;
    }

    // update data
    public void updateData(int id, String title, String note) {

        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("UPDATE "+TABLE_NAME+" set NOTE_TITLE = '"+title+"', NOTE = '"+note+"' where ID = "+id );
    }
}
